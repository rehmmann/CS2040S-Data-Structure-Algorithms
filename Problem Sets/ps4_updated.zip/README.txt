- Open the ps4 folder (the one that this README is in) as an IntelliJ Project (this should have been configured)
  - If not, File -> Close Project
  - Import Project and simply keep pressing "next" to configure the ps4 folder as an IntelliJ project

- The .txt files in `games/` are normal Tic-Tac-Toe games for you to try with the GameTree class.

- The .txt files in `variants/` are Tic-Tac-Toe variants for you to try with the GameTree class.