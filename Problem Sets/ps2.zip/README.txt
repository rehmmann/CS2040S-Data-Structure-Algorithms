Instructions for Setting Up PS2 on IntelliJ
-------------------------------------------
Extract the entire 'ps2' directory in the zip file to a directory of your choice on your computer.
Then, go to IntelliJ and click File > Open. Select the 'ps2' directory that you have extracted and click 'Ok'. 